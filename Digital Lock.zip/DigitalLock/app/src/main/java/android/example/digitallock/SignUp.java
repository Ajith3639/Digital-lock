package android.example.digitallock;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SignUp extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up);
        TextView Login=findViewById(R.id.AlreadyLogin);
        Login.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                Intent ShiftIntent = new Intent(SignUp.this, SignIn.class);

                // Start the new activity
                startActivity(ShiftIntent);
            }
        });

}}
