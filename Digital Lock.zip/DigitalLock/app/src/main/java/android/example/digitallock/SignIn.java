package android.example.digitallock;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SignIn extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_in);
        TextView Register=findViewById(R.id.RegisterHere);
        Register.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                Intent ShifIntent = new Intent(SignIn.this, SignUp.class);

                // Start the new activity
                startActivity(ShifIntent);
            }
        });

    }}
